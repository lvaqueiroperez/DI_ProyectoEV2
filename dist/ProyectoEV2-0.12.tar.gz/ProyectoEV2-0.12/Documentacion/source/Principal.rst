Principal module
================

.. automodule:: Principal
    :members:
    :undoc-members:
    :show-inheritance:
