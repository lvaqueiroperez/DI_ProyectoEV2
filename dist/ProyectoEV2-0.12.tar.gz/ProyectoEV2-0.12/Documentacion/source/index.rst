.. proyectoEV2_Doc documentation master file, created by
   sphinx-quickstart on Mon Mar 16 13:36:55 2020.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to proyectoEV2_Doc's documentation!
===========================================

.. toctree::
   :maxdepth: 10
   :caption: Contents:
Documentacion.rst
modules.rst



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
