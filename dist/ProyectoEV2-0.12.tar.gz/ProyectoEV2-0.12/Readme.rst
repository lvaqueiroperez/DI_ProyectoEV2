Proyecto para la Segunda Evaluación para la gestión de Clientes y Servicios usando Gtk Python.

Documentación del proyecto en la carpeta "Documentacion/build/html/Documentacion.html".

La aplicación se iniciará escribiendo en el terminal "Principal".